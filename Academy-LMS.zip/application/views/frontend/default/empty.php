<div class="row">
  <div class="col-md-12" style="padding: 20px 40px; text-align: center;">
      <h4><?php echo $page_body; ?></h4>
  </div>
</div>
